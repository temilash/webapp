from app import db

class Property(db.Model):#db creation and fields
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(500))
    month = db.Column(db.String(20))
    expense = db.Column(db.String(20))
    amount = db.Column(db.Float)

