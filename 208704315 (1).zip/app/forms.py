#!/usr/bin/python
# -*- coding: utf-8 -*-
from flask_wtf import FlaskForm
from wtforms import TextAreaField, \
    FloatField, SelectField, validators
from wtforms.validators import InputRequired, length


class addincomeform(FlaskForm):

    # making form to make new income/expense
    # adding fields

    description = TextAreaField('expense Description',
                                validators = [InputRequired(),
                                            length(max = 200)])
    month = SelectField('Choose an option', choices = [
        ('January', 'January'),
        ('February', 'February'),
        ('March', 'March'),
        ('April', 'April'),
        ('May', 'May'),
        ('June', 'June'),
        ('July', 'July'),
        ('August', 'August'),
        ('September', 'September'),
        ('October', 'October'),
        ('November', 'November'),
        ('December', 'December'),
    ])
    expense = SelectField('Choose an option', choices = [('Expense',
                          'Expense'), ('Income', 'Income')])
    amount = FloatField('amount', validators = [InputRequired(),
                        validators.NumberRange(min = 1, max = 1000000)])


class goalform(FlaskForm):  # making form to make new goal

    # adding all fields

    description = TextAreaField('Goal description',
                                validators = [InputRequired(),
                                            length(max = 200)])
    month = SelectField('Choose an option', choices = [
        ('January', 'January'),
        ('February', 'February'),
        ('March', 'March'),
        ('April', 'April'),
        ('May', 'May'),
        ('June', 'June'),
        ('July', 'July'),
        ('August', 'August'),
        ('September', 'September'),
        ('October', 'October'),
        ('November', 'November'),
    ])
    expense = SelectField('Choose an option', choices = [('Goal', 'Goal'
                                                        )])
    amount = FloatField('amount', validators = [InputRequired(),
                        validators.NumberRange(min = 1, max = 1000000)])
