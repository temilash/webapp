from flask import render_template, flash, request
from app import app, db, models
from .forms import addincomeform, goalform
from flask_sqlalchemy import SQLAlchemy

WTF_CSRF_ENABLED = True
app.secret_key = "testingkey"


@app.route("/expenses", methods=("GET", "POST"))  # Define '/' route


def expenses():
    # query db
    p = models.Property.query.filter_by(expense = "Expense").all()
    if request.method == "POST":  # if button clicked
        for d in p:
            if request.form.get("Delete") == str(
                d.id
            ):  # if id of row sent back delete row
                expense = models.Property.query.get(d.id)
                db.session.delete(expense)  # delete from db
                db.session.commit()
                p = models.Property.query.filter_by(expense = "Expense").all()
    flash("Successfully received form data")
    return render_template("expenses.html", title = "All expenses", expenses = p)


@app.route("/incomes", methods=("GET", "POST"))  # Define '/' route


def incomes():
    p = models.Property.query.filter_by(expense="Income").all()  # query db
    if request.method == "POST":  # if button clicked
        for d in p:
            if request.form.get("Delete") == str(
                d.id
            ):  # if id of row sent back delete row
                expense = models.Property.query.get(d.id)
                db.session.delete(expense)  # delete from db
                db.session.commit()
                p = models.Property.query.filter_by(expense = "Income").all()
    flash("Successfully received form data")
    return render_template("incomes.html", title = "All Incomes", expenses = p)


@app.route("/addincome", methods=("GET", "POST"))  # Define '/' route


def addincome():
    form = addincomeform()  # form
    if form.validate_on_submit():  # if form has been clicked
        p = models.Property(
            description=form.description.data,
            amount=form.amount.data,
            month=form.month.data,
            expense=form.expense.data,
        )  # create new db object
        db.session.add(p)  # add to db
        db.session.commit()
        flash("Successfully received form data")
    return render_template("addincome.html", title = "Add Income", form = form)


@app.route("/goal", methods = ("GET", "POST"))  # Define '/' route


def goal():
    form = goalform()
    if form.validate_on_submit():  # if button clicked
        p = models.Property(
            description = form.description.data,
            amount = form.amount.data,
            month = form.month.data,
            expense = form.expense.data,
        )
        # new db row
        dbgoal = models.Property.query.filter_by(
            expense = "Goal"
        ).all()  # if goal already exists delete it
        if dbgoal != []:
            for d in dbgoal:
                db.session.delete(d)  # delete
        db.session.add(p)  # add new goal
        db.session.commit()
        flash("Successfully received form data")
    return render_template("goal.html", title = "Add Goal", form = form)


@app.route("/", methods=("GET", "POST"))  # Define '/' route


def index():
    comp = 0
    inc = []
    exp = []
    inctotal = 0
    exptotal = 0
    for income in models.Property.query.filter_by(expense = "Income").all():
        if income.amount > comp:  # finding out total income and largest
            comp = income.amount
            inc = income
        inctotal = income.amount + inctotal
    comp = 0
    for income in models.Property.query.filter_by(expense = "Expense").all():
        if income.amount > comp:  # finding out total expense and largest
            comp = income.amount
            exp = income
        exptotal = income.amount + exptotal
    dbgoal = models.Property.query.filter_by(expense = "Goal").all()
    if dbgoal == []:  # checking there is a goal
        dbgoal = 0
    if request.method == "POST":  # if goal exists delete it
        if request.form["Delete"] == "Delete":  # if delete button clicked
            dbgoal = models.Property.query.filter_by(expense = "Goal").all()
            if dbgoal != []:  # find goal in db and delete
                for d in dbgoal:
                    db.session.delete(d)
                    db.session.commit()
                    dbgoal = 0
    total = inctotal - exptotal
    percent = 0
    for d in dbgoal:
        percent = ((total/d.amount)*100)//1
    if total <= 0:  # if total less than 0 total = -1
        total = -1
        percent = 0
    if dbgoal != 0:
        for d in dbgoal:
            if total > d.amount:
                total = -2  # checking to see if they reached goal
    return render_template(
        "landing.html",
        goal = dbgoal,
        Expense = exp,
        Income = inc,
        totalincome = inctotal,
        expensetotal = exptotal,
        total = total,
        percent = percent
    )
